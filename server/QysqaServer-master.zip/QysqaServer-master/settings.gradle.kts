rootProject.name = "QysqaServer"
