package com.example.qysqaserver.dto.params.enums;

public enum AchievementType {
    COMMON, RARE, EPIC, LEGENDARY
}
