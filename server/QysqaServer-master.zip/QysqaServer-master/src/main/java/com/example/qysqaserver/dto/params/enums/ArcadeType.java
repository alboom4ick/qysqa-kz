package com.example.qysqaserver.dto.params.enums;

public enum ArcadeType {
    MATCHING, FLASHCARD
}
