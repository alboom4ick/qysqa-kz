package com.example.qysqaserver.dto.params.enums;

public enum QuizProcess {
    READY_TO_START,
    IN_PROGRESS,
    PASSED,
    FAILED
}
