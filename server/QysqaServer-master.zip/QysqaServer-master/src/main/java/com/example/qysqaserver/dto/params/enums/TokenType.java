package com.example.qysqaserver.dto.params.enums;

public enum TokenType {
    BEARER
}
