package com.example.qysqaserver.dto.request;

public record FullNameChangeRequest(String firstName, String lastName) {
}
