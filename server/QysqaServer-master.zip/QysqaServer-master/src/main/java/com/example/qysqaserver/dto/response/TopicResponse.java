package com.example.qysqaserver.dto.response;

public class TopicResponse {

}
