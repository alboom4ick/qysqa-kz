package com.example.qysqaserver.entities.enums;

public enum AchievementType {
    COMMON, RARE, EPIC, LEGENDARY
}
