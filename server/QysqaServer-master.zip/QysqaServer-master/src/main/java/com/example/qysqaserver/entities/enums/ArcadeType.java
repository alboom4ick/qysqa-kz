package com.example.qysqaserver.entities.enums;

public enum ArcadeType {
    MATCHING, FLASHCARD
}
