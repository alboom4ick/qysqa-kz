package com.example.qysqaserver.entities.enums;

import lombok.Getter;
import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor
@Getter
public enum Level {
    EASY,
    MEDIUM,
    HARD;
}
