package com.example.qysqaserver.entities.enums;

public enum QuizProcess {
    READY_TO_START,
    IN_PROGRESS,
    PASSED,
    FAILED
}
