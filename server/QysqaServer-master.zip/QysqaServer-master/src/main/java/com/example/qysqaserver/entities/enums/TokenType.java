package com.example.qysqaserver.entities.enums;

public enum TokenType {
    BEARER
}
