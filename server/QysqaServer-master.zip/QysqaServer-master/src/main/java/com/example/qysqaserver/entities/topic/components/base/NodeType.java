package com.example.qysqaserver.entities.topic.components.base;

public enum NodeType {
    TEXT, ICON_TEXT, TITLED_CONTAINER, CENTERED_CONTAINER, IMAGE, STACK
}
