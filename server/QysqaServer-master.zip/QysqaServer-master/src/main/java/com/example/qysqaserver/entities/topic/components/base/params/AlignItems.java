package com.example.qysqaserver.entities.topic.components.base.params;

public enum AlignItems {
    START, CENTER, END, STRETCH
}
