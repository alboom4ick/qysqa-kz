package com.example.qysqaserver.entities.topic.components.base.params;

public enum Background {
    PRIMARY, DEFAULT, SECONDARY, TERTIARY;
}
