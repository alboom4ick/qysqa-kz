package com.example.qysqaserver.entities.topic.components.base.params;

public enum BorderType {
    SOLID, DASHED, DOTTED, NONE;
}
