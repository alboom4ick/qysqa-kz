package com.example.qysqaserver.entities.topic.components.base.params;

public enum FlexWrap {
    WRAP, NOWRAP;
}
