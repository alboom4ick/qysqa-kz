package com.example.qysqaserver.entities.topic.components.base.params;

public enum FontColor {
    PRIMARY, DEFAULT, SECONDARY, TERTIARY
}
