package com.example.qysqaserver.entities.topic.components.base.params;

public enum FontSize {
    BIG, MEDIUM, SMALL
}
