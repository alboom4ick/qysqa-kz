package com.example.qysqaserver.entities.topic.components.base.params;

public enum JustifyContent {
    SPACE_BETWEEN, SPACE_AROUND, CENTER, STRETCH
}
