package com.example.qysqaserver;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class QysqaServerApplicationTests {

    @Test
    void contextLoads() {
    }

}
